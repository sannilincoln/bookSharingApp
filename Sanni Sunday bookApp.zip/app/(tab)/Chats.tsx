import { Text, View } from "react-native";
import React, { Component } from "react";

export class Chats extends Component {
  render() {
    return (
      <View>
        <Text>Chats</Text>
      </View>
    );
  }
}

export default Chats;
