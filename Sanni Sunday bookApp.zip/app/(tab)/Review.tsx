import { View, Text } from "react-native";
import React from "react";

const Review = () => {
  return (
    <View>
      <Text>Review</Text>
    </View>
  );
};

export default Review;
